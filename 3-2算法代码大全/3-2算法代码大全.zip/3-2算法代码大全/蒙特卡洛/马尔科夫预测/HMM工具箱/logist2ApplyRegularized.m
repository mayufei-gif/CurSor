﻿% 文件: logist2ApplyRegularized.m
% 说明: 自动添加的注释占位，请根据需要补充。
% 生成: 2025-08-31 23:06
% 注释: 本文件头由脚本自动添加

function prob = logist2ApplyRegularized(net, features)  % 详解: 执行语句

prob = glmfwd(net, features')';  % 详解: 赋值：将 glmfwd(...) 的结果保存到 prob




