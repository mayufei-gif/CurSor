﻿% 文件: unif_discrete_sample.m
% 说明: 自动添加的注释占位，请根据需要补充。
% 生成: 2025-08-31 23:06
% 注释: 本文件头由脚本自动添加

function r = unif_discrete_sample(n, nrows, ncols)  % 详解: 执行语句

r = ceil(n .* rand(nrows,ncols));  % 详解: 赋值：将 ceil(...) 的结果保存到 r




