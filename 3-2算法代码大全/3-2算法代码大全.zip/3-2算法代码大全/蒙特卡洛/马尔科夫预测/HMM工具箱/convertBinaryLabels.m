﻿% 文件: convertBinaryLabels.m
% 说明: 自动添加的注释占位，请根据需要补充。
% 生成: 2025-08-31 23:06
% 注释: 本文件头由脚本自动添加

% labels01 = (labelsPM+1)/2; % maps -1->0, +1->1
% labelsPM = (2*labels01)-1; % maps 0,1 -> -1,1


