﻿% 文件: plot_axis_thru_origin.m
% 说明: 自动添加的注释占位，请根据需要补充。
% 生成: 2025-08-31 23:06
% 注释: 本文件头由脚本自动添加

function plot_axis_thru_origin()  % 详解: 函数定义：plot_axis_thru_origin()

lnx=line(get(gca,'xlim'),[0 0]); lny=line([0 0],get(gca,'ylim'));  % 详解: 赋值：将 line(...) 的结果保存到 lnx




