﻿% 文件: testHMM.m
% 说明: 自动添加的注释占位，请根据需要补充。
% 生成: 2025-08-31 23:06
% 注释: 本文件头由脚本自动添加

% Run all the demos, to check everything is "syntactically correct"
mhmm_em_demo  % 详解: 执行语句
dhmm_em_demo  % 详解: 执行语句
dhmm_em_online_demo  % 详解: 执行语句
fixed_lag_smoother_demo  % 详解: 执行语句




