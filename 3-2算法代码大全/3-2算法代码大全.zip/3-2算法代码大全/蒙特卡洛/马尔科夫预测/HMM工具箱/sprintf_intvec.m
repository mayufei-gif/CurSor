﻿% 文件: sprintf_intvec.m
% 说明: 自动添加的注释占位，请根据需要补充。
% 生成: 2025-08-31 23:06
% 注释: 本文件头由脚本自动添加

function s = sprintf_intvec(v)  % 详解: 执行语句

s = sprintf('%d,', v);  % 详解: 赋值：将 sprintf(...) 的结果保存到 s
s = s(1:end-1);  % 详解: 赋值：将 s(...) 的结果保存到 s





