function y = malthus(r,xdata)
y = 3.9*exp(r*(xdata-1790));
